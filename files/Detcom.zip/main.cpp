#include <stdio.h>
#include <stdlib.h>
int d1();/*d for Determinant, number for order*/
int d2();
int d3();
int d4();
int main(){
	int dp,lcat,loo=1;/*dp=display, lcat=lower category number, loo=loop number*/
	char hcat;/*hcat=higher category number*/
	printf("Detcom [version 1.1.1.11]\n");
	printf("(c)harukaworks.link all rights reserved\n");
	printf("\n");
	while (1){
		hcat = 'd';
		printf(">");
		scanf("%c %d %d",&hcat,&lcat,&loo);
		if(loo==0)
			loo=loo+1;
		if((hcat=='d'||hcat=='D'))/*command 'D num1 num2' for determinant*/
			switch(lcat){/*determine order of the determinant*/
				case 1:
					for(;loo>=1;loo--){
						dp=d1();
						printf("%d\n",dp);
					}
					break;
				case 2:
					for(;loo>=1;loo--){
						dp=d2();
						printf("%d\n",dp);
					}
					break;
				case 3:
					for(;loo>=1;loo--){
						dp=d3();
						printf("%d\n",dp);
					}
					break;
				case 4:
					for(;loo>=1;loo--){
						dp=d4();
						printf("%d\n",dp);
					}
					break;
				default:
					printf("Please insert the right order of the Det.\n");
			}
		else if(hcat=='e'||hcat=='E')/*command 'E num1 num2' for exit*/
			break;
		else if(hcat=='c'||hcat=='C')/*command 'C num1 num2' for clear screen*/
			system("cls");
		else if(hcat=='?'){/*command '? num1 num2' for helps*/
			printf("d num1 num2----/Insert num2 piece(s) of num1-order-Det.\n");
			printf("e num1 num2----/Exit with num1 times num2 as return code\n");
			printf("c num1 num2----/Clear screen.\n");
			printf("!You may incert in either UPPER CASE or lower case.\n");
			printf("!You are not allowed to ignore the numbers.\n");
		}
	}
	return 0;
}
int d1(){
	int q;
	printf("You are calculating a 1-order-Det.\n");
	printf("Insert your first line.\n");
	printf(">");
	scanf("%d",&q);
	return q;
}
int d2(){
	int a1,b1,a2,b2,q;
	printf("You are calculating a 2-order-Det.\n");
	printf("Insert your first line.\n");
	printf(">");
	scanf("%d %d",&a1,&b1);
	printf("Insert your second line.\n");
	printf(">");
	scanf("%d %d",&a2,&b2);
	q = a1*b2-a2*b1;
	return q;
}
int d3(){
	int a1,b1,c1,a2,b2,c2,a3,b3,c3,q;
	printf("You are calculating a 3-order-Det.\n");
	printf("Insert your first line.\n");
	printf(">");
	scanf("%d %d %d",&a1,&b1,&c1);
	printf("Insert your second line.\n");
	printf(">");
	scanf("%d %d %d",&a2,&b2,&c2);
	printf("Insert your third line.\n");
	printf(">");
	scanf("%d %d %d",&a3,&b3,&c3);
	q = a1*b2*c3+a2*b3*c1+a3*b1*c2-a1*b3*c2-a2*b1*c3-a3*b2*c1;
	return q;
}
int d4(){
	int a1,b1,c1,d1,a2,b2,c2,d2,a3,b3,c3,d3,a4,b4,c4,d4,q;
	printf("You are calculating a 4-order-Det.\n");
	printf("Insert your first line.\n");
	printf(">");
	scanf("%d %d %d %d",&a1,&b1,&c1,&d1);
	printf("Insert your second line.\n");
	printf(">");
	scanf("%d %d %d %d",&a2,&b2,&c2,&d2);
	printf("Insert your third line.\n");
	printf(">");
	scanf("%d %d %d %d",&a3,&b3,&c3,&d3);
	printf("Insert your fourth line.\n");
	printf(">");
	scanf("%d %d %d %d",&a4,&b4,&c4,&d4);
	q = a1*b2*c3*d4-a2*b3*c4*d1+a3*b4*c1*d2-a4*b1*c2*d3+d1*c2*b3*a4-d2*c3*b4*a1+d3*c4*b1*a2-d4*c1*b2*a3+a1*b3*c4*d2-a3*b4*c2*d1+a4*b2*c1*d3-a2*b1*c3*d4+d1*c3*b4*a2-d3*c4*b2*a1+a4*c2*b1*a3-d2*c1*b3*a4+a1*b4*c2*d3-a4*b2*c3*d1+a2*b3*c1*d4-a3*b1*c4*d2+d1*c4*b2*a3-d4*c2*b3*a1+d2*c3*b1*a4-d3*c1*b4*a2;
	return q;
}